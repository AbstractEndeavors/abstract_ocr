#!/usr/bin/env python3
"""
abstract_ocr.ocr_utils.layered_ocr
----------------------------------
Unified OCR orchestration for multi-engine text extraction:
- Tesseract
- EasyOCR
- PaddleOCR (via PaddleManager, CPU-only)
"""

from ..imports import *
from .paddle_manager import PaddleManager


# -----------------------------------------------------
# Image Preprocessing
# -----------------------------------------------------
def preprocess_image(input_path: Path, output_path: Path) -> None:
    """Convert to grayscale and apply adaptive thresholding."""
    img = cv2.imread(str(input_path))
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    thresh = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 11, 2
    )
    cv2.imwrite(str(output_path), thresh)


# -----------------------------------------------------
# OCR Backends
# -----------------------------------------------------
def tesseract_ocr_img(img: np.ndarray) -> pd.DataFrame:
    """Perform OCR using Tesseract."""
    pil = Image.fromarray(img)
    df = pytesseract.image_to_data(
        pil,
        config=Ocr_Config.TESS_PSM,
        output_type=pytesseract.Output.DATAFRAME
    )
    return df[df.text.notnull()]


def easyocr_ocr(path: Path) -> pd.DataFrame:
    """Perform OCR using EasyOCR (GPU optional)."""
    reader = easyocr.Reader(Ocr_Config.EASY_LANGS, gpu=False)
    recs = []
    for bbox, text, conf in reader.readtext(str(path)):
        xs, ys = zip(*bbox)
        recs.append({
            "text": text,
            "conf": conf * 100,
            "left": min(xs), "top": min(ys),
            "width": max(xs) - min(xs),
            "height": max(ys) - min(ys),
        })
    return pd.DataFrame(recs)


def paddleocr_ocr(path: Path) -> pd.DataFrame:
    """Perform OCR using PaddleOCR (CPU-only)."""
    ocr = PaddleManager.get_instance().ocr
    recs = []
    for page in ocr.ocr(str(path), cls=False):
        if not page:
            continue
        for bbox, (text, conf) in page:
            xs, ys = zip(*bbox)
            recs.append({
                "text": text,
                "conf": conf,
                "left": min(xs), "top": min(ys),
                "width": max(xs) - min(xs),
                "height": max(ys) - min(ys),
            })
    return pd.DataFrame(recs)


# -----------------------------------------------------
# Layered OCR Logic
# -----------------------------------------------------
def layered_ocr_img(img: np.ndarray, engine: str = "tesseract") -> pd.DataFrame:
    """Perform OCR with multiple backends (layered OCR)."""
    tmp = Path("/tmp/ocr_tmp.png")
    cv2.imwrite(str(tmp), img)

    if engine == "tesseract":
        df = tesseract_ocr_img(img)
    elif engine == "easy":
        df = easyocr_ocr(tmp)
    elif engine == "paddle":
        df = paddleocr_ocr(tmp)
    else:
        logger.warning(f"⚠️ Unknown OCR engine '{engine}', skipping.")
        return pd.DataFrame(columns=["text", "left", "top", "width", "height", "conf"])

    if df is None or df.empty:
        return pd.DataFrame(columns=["text", "left", "top", "width", "height", "conf"])

    # Ensure consistent structure
    required_cols = ["text", "left", "top", "width", "height"]
    for col in required_cols:
        if col not in df.columns:
            df[col] = 0

    try:
        df = df.sort_values(["left", "top"]).reset_index(drop=True)
    except Exception as e:
        logger.warning(f"Could not sort OCR output for engine {engine}: {e}")

    return df

